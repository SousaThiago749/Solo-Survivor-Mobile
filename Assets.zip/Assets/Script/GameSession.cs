using UnityEngine;
using System.Collections.Generic;

public class GameSession : MonoBehaviour
{
    public static GameSession instancia;
    public int ultimoRoundAlcancado;

    public float savedPlayerSpeed;
    public int savedPlayerLevel;
    public List<string> savedPowers = new List<string>();

    public bool isReviving = false;

    // Referências para acessar mesmo na Scene End
    public PlayerMovement playerMovement;
    public PlayerLevelSystem playerLevelSystem;
    public PowerManager powerManager;

    void Awake()
    {
        if (instancia == null)
        {
            instancia = this;
            DontDestroyOnLoad(gameObject); // persiste entre cenas
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    public void SalvarRound(int round)
    {
        ultimoRoundAlcancado = round;
    }

public void SavePlayerState(PlayerMovement playerMovement, PlayerLevelSystem playerLevelSystem, PowerManager powerManager)
{
    savedPlayerSpeed = playerMovement != null ? playerMovement.speed : 3f; // valor padrão
    savedPlayerLevel = playerLevelSystem != null ? playerLevelSystem.nivel : 1;

    savedPowers.Clear();

    if (powerManager != null && powerManager.powersEscolhidos != null)
    {
        savedPowers.AddRange(powerManager.powersEscolhidos);
    }

    isReviving = true;
}

    public void ClearReviveFlag()
    {
        isReviving = false;
    }
}
