using UnityEngine;
using System.Collections.Generic;

public class PowerManager : MonoBehaviour
{
    // Referências aos seus scripts de manager (arraste no Inspector)
    public PunchManager     punchManager;
    public FireBallManager  fireBallManager;
    public SunStrikeManager sunStrikeManager;
    public LightningManager lightningManager;
    public WaterBallManager waterBallManager;
    public BlackHoleManager blackHoleManager;
    public GlacialManager   glacialManager;

    // Lista de poderes escolhidos
    public List<string> powersEscolhidos = new List<string>();

    void Awake()
    {
        // mantém este objeto vivo entre cenas
        DontDestroyOnLoad(gameObject);
    }

    void Start()
    {
        // se estamos no fluxo de revive, reaplica tudo
        if (GameSession.instancia != null && GameSession.instancia.isReviving)
        {
            foreach (string nome in GameSession.instancia.savedPowers)
                ChoosePower(nome);

            GameSession.instancia.ClearReviveFlag();
        }
    }

    public void ChoosePower(string nomePoder)
    {
        // evita duplicata
        if (!powersEscolhidos.Contains(nomePoder))
            powersEscolhidos.Add(nomePoder);

        // executa o LevelUp correspondente
        switch (nomePoder)
        {
            case "FireBall":
                fireBallManager?.LevelUp();
                break;
            case "SunStrike":
                sunStrikeManager?.LevelUp();
                break;
            case "LightningStrike":
                lightningManager?.LevelUp();
                break;
            case "WaterBall":
                waterBallManager?.LevelUp();
                break;
            case "BlackHole":
                blackHoleManager?.LevelUp();
                break;
            case "Glacial":
                glacialManager?.LevelUp();
                break;
            default:
                Debug.LogWarning($"ChoosePower: poder '{nomePoder}' não reconhecido.");
                break;
        }
    }
}
