using UnityEngine;
using UnityEngine.SceneManagement;

public class AdSceneController : MonoBehaviour
{
    private float timer = 0f;
    public float adDuration = 5f; // segundos que a "ad" fica

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= adDuration)
        {
            // Volta para a cena do jogo (Main)
            SceneManager.LoadScene("Main");
        }
    }
}
